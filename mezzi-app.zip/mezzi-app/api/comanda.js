export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { base64, mime } = req.body;
  if (!base64 || !mime) {
    return res.status(400).json({ error: "base64 e mime são obrigatórios" });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "GEMINI_API_KEY não configurada" });
  }

  const prompt = `Leia esta imagem de uma comanda de restaurante brasileiro e retorne SOMENTE JSON válido, sem markdown, sem texto extra.

Esquema exato:
{"mesa":"numero MS","pedido":"numero PE","garcom_codigo":"codigo como C201","data_hora_comanda":"YYYY-MM-DDTHH:mm:00","pratos":[{"codigo":"string","nome":"string","quantidade":1}]}

Use null para campos não encontrados. Para data_hora_comanda use o formato ISO 8601 com a data e hora exatas impressas na comanda.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: mime, data: base64 } },
              { text: prompt }
            ]
          }],
          generationConfig: { temperature: 0, maxOutputTokens: 800 }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({ error: data });
    }

    const raw = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!raw) {
      return res.status(500).json({ error: "Resposta vazia do Gemini: " + JSON.stringify(data) });
    }

    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    return res.status(200).json(parsed);

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
