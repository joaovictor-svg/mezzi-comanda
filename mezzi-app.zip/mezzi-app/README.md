# MEZZI · Tempo de Entrega

App para registrar e analisar o tempo de entrega de comandas da cozinha ao salão.
Usa **Google Gemini** para leitura das fotos — **100% gratuito**.

---

## Deploy no Vercel (~5 minutos)

### 1. Criar conta Vercel
Acesse https://vercel.com e crie uma conta gratuita (pode usar login com Google).

### 2. Obter API Key do Google Gemini (gratuita)
- Acesse https://aistudio.google.com
- Clique em **"Get API key"** → **"Create API key"**
- Copie a chave (começa com `AIza...`)

### 3. Instalar Vercel CLI
No terminal:
```
npm install -g vercel
```

### 4. Fazer deploy
Na pasta do projeto:
```
cd mezzi-app
vercel
```
Siga as perguntas:
- "Set up and deploy?" → Y
- "Which scope?" → sua conta
- "Link to existing project?" → N
- "Project name?" → mezzi-comanda
- "In which directory is your code?" → ./
- "Override settings?" → N

### 5. Configurar API Key
No painel do Vercel:
- Vá em seu projeto → **Settings** → **Environment Variables**
- Adicione: `GEMINI_API_KEY` = `AIzaSUA_CHAVE_AQUI`
- Clique em **Save**
- Vá em **Deployments** → clique nos 3 pontinhos → **Redeploy**

### 6. Acessar o app
O Vercel gera uma URL tipo `https://mezzi-comanda.vercel.app`.
Abra no celular e **adicione à tela inicial** para usar como app nativo.

---

## Estrutura do projeto

```
mezzi-app/
├── api/
│   └── comanda.js      ← Serverless function (chama Google Gemini)
├── public/
│   └── index.html      ← App completo
├── package.json
├── vercel.json
└── README.md
```

---

## Limites gratuitos do Gemini
- **1.500 chamadas por dia** (plano gratuito)
- Em um turno com 100 comandas: usa menos de 7% do limite diário
- Sem necessidade de cartão de crédito

---

## Como usar
1. Abra o app e configure a sessão (data + turno)
2. Toque em **"Fotografar Comanda"** quando a comanda chegar ao salão
3. O app lê automaticamente: mesa, consultor, hora, pratos
4. Registra o horário da foto como hora de entrega
5. Calcula o tempo de espera automaticamente
6. Veja análises na aba 📊
